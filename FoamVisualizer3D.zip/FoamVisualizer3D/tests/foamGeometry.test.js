import test from 'node:test';
import assert from 'node:assert/strict';
import { createFoamGeometry } from '../src/lib/foamGeometry.js';

function topology(geometry) {
  const positions = geometry.getAttribute('position');
  const edges = new Map(); let volume = 0;
  const key = (i) => [positions.getX(i), positions.getY(i), positions.getZ(i)].map(x => x.toFixed(5)).join(',');
  for (let i=0; i<positions.count; i+=3) {
    const p = [i,i+1,i+2].map(j => [positions.getX(j), positions.getY(j), positions.getZ(j)]);
    volume += (p[0][0]*(p[1][1]*p[2][2]-p[1][2]*p[2][1]) + p[0][1]*(p[1][2]*p[2][0]-p[1][0]*p[2][2]) + p[0][2]*(p[1][0]*p[2][1]-p[1][1]*p[2][0])) / 6;
    for (const [a,b] of [[i,i+1],[i+1,i+2],[i+2,i]]) { const e = [key(a),key(b)].sort().join('|'); edges.set(e, (edges.get(e)||0)+1); }
  }
  return { edges, volume };
}
for (const points of [
  [{x:-1,y:-0.5},{x:1,y:-0.5},{x:1,y:0.5},{x:-1,y:0.5}],
  [{x:-1,y:0.5},{x:1,y:0.5},{x:1,y:-0.5},{x:-1,y:-0.5}],
]) test('foam solid is closed and has expected volume for either outline winding', () => {
  const geometry=createFoamGeometry({width:6,height:4,thickness:0.6,depth:0.35}, points);
  const {edges,volume}=topology(geometry);
  assert.ok([...edges.values()].every(count=>count===2), 'each mesh edge must be shared by two faces');
  assert.ok(Math.abs(volume - (6*4*0.6 - 2*1*0.35)) < 1e-5, `volume: ${volume}`);
  geometry.dispose();
});

test('STL exporter writes the foam dimensions in millimeters', async () => {
  const { STLExporter } = await import('three/addons/exporters/STLExporter.js');
  const THREE = await import('three');
  const geometry = createFoamGeometry({width: 6,height: 4,thickness: 0.6,depth: 0.35}, [{x:-1,y:-0.5},{x:1,y:-0.5},{x:1,y:0.5},{x:-1,y:0.5}]);
  geometry.scale(25.4,25.4,25.4);
  const data = new STLExporter().parse(new THREE.Mesh(geometry), {binary:true});
  const faceCount = data.getUint32(80,true);
  assert.ok(faceCount > 0);
  assert.equal(data.byteLength, 84 + 50 * faceCount);
  geometry.computeBoundingBox();
  assert.ok(Math.abs(geometry.boundingBox.max.x - geometry.boundingBox.min.x - 152.4) < 1e-4);
  geometry.dispose();
});
