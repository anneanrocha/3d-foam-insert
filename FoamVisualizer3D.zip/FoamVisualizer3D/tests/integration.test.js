import test from 'node:test';
import assert from 'node:assert/strict';
import { createFoamAdapter } from '../src/integration/createFoamAdapter.js';
import { prepareOutline } from '../src/integration/outline.js';

const contour = {units: 'mm', points: [{x: 100, y: 40}, {x: 150.8, y: 40}, {x: 150.8, y: 65.4}, {x: 100, y: 65.4}]};

test('converts physical points and centers an offset contour', () => {
  const result = prepareOutline(contour);
  assert.equal(result.units, 'in');
  assert.ok(Math.abs(result.points[0].x + 1) < 1e-10);
  assert.ok(Math.abs(result.points[0].y + 0.5) < 1e-10);
  assert.ok(Math.abs(result.points[2].x - 1) < 1e-10);
});

test('adapter loads tools and outline and passes project to host', async () => {
  const saved = [];
  const adapter = createFoamAdapter({
    listTools: async () => [{id: 't1', name: 'Wrench'}],
    loadOutline: async tool => { assert.equal(tool.id, 't1'); return contour; },
    saveProject: async project => { saved.push(project); },
  });
  const [tool] = await adapter.listTools();
  assert.deepEqual(await adapter.listToolboxes(), []);
  assert.deepEqual(await adapter.loadOutline(tool), contour);
  await adapter.saveProject({toolId: tool.id});
  assert.deepEqual(saved, [{toolId: 't1'}]);
});

test('invalid backend data and save errors are reported', async () => {
  const adapter = createFoamAdapter({listTools: async () => [{name: 'missing id'}], loadOutline: async () => ({units:'px', points:[]}), saveProject: async () => { throw new Error('offline'); }});
  await assert.rejects(adapter.listTools(), /id and a name/);
  await assert.rejects(adapter.loadOutline({}), /Unsupported outline units/);
  await assert.rejects(adapter.saveProject({}), /offline/);
});

test('rejects an absent or self-intersecting outline before rendering', async () => {
  const adapter = createFoamAdapter({listTools: async () => [], loadOutline: async () => null});
  await assert.rejects(adapter.loadOutline({}), /no outline/);
  assert.throws(() => prepareOutline({units:'in', points:[{x:0,y:0},{x:3,y:3},{x:0,y:3},{x:2,y:0}]}), /cross or touch/);
});

test('outline drafts can be listed and loaded with their original source ID', async () => {
  const adapter = createFoamAdapter({
    listTools: async () => [],
    listOutlines: async () => [{id:'draft-1', name:'Draft'}],
    loadOutline: async item => { assert.equal(item.sourceType, 'outline'); assert.equal(item.id, 'draft-1'); return contour; },
  });
  const [draft] = await adapter.listOutlines();
  assert.deepEqual(await adapter.loadOutline({...draft, sourceType:'outline'}), contour);
});
