import test from 'node:test';
import assert from 'node:assert/strict';
import { getOutlinePoints, normalizeSettings, initialSettings } from '../src/lib/foam.js';
import { getGridfinityFromSize } from '../src/lib/gridfinity.js';

test('converts millimeter outlines to inches and removes closing point', () => {
  const points = getOutlinePoints({ units: 'mm', points: [{x: 0, y: 0}, {x: 25.4, y: 0}, {x: 0, y: 25.4}, {x: 0, y: 0}] });
  assert.equal(points.length, 3);
  assert.ok(Math.abs(points[1].x - 1) < 1e-10);
  assert.ok(Math.abs(points[2].y - 1) < 1e-10);
});
test('rejects invalid outlines', () => {
  assert.throws(() => getOutlinePoints({ units: 'mm', points: [{x: 0,y: 0},{x: 1,y: 1},{x: 2,y: 2}] }));
  assert.throws(() => getOutlinePoints({ units: 'px', points: [] }));
});
test('keeps the pocket within foam and depth below thickness', () => {
  const shape = [{x: -2,y: -1},{x: 2,y: -1},{x: 2,y: 1},{x: -2,y: 1}];
  const value = normalizeSettings({...initialSettings, width: 1, height: 1, x: 99, depth: 99}, shape);
  assert.ok(value.width > 4 && value.height > 2);
  assert.ok(value.x < 1 && value.depth < value.thickness);
});
test('rounds grid dimensions up to the 42 mm pitch', () => {
  const grid = getGridfinityFromSize(85, 42);
  assert.equal(grid.columns, 3); assert.equal(grid.rows, 1);
});
