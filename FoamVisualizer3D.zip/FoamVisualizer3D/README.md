# Foam Visualizer 3D

A React/Vite foam insert editor with a Three.js preview, configurable pocket, Gridfinity base and STL, DXF and SVG exports. The standalone app includes sample tools for development; connecting it to the real ToolKaiser account and data requires the host application.

## Development

Use a Node version supported by Vite 8 (Node 20.19+ or 22.12+).

```sh
npm ci
npm run dev
npm run lint
node --test tests/*.test.js
npm run build
```

## Integrating the existing platform

Start with `src/integration/platformAdapter.example.js`: connect the existing services and map their real response fields there. The example is a template; its service names are not real backend calls. Render `ConnectedFoamDesigner` with the resulting adapter.

The `ConnectedFoamDesigner` component loads the current user's tools and outline drafts, lets them choose an item, loads its outline and passes it to the 3D editor. `createFoamAdapter` is the boundary for the existing platform services: no backend URL, schema, credentials or API is assumed.

```jsx
import { useMemo } from 'react';
import ConnectedFoamDesigner from './integration/ConnectedFoamDesigner.jsx';
import { createFoamAdapter } from './integration/createFoamAdapter.js';

function FoamPage({ toolService, outlineService, toolboxService, projectService, savedProject }) {
  const adapter = useMemo(() => createFoamAdapter({
    listTools: async () => {
      const records = await toolService.list();
      // Map your API response to { id, name, toolboxId? }.
      return records.map(record => ({ id: record.id, name: record.name, toolboxId: record.toolboxId }));
    },
    listOutlines: async () => {
      const records = await outlineService.list();
      return records.map(record => ({ id: record.id, name: record.name }));
    },
    listToolboxes: async () => {
      const records = await toolboxService.list();
      return records.map(record => ({ id: record.id, name: record.name }));
    },
    loadOutline: async (item) => {
      // Map your stored outline to { units: 'mm' | 'in', points: [{ x, y }] }.
      return item.sourceType === 'outline'
        ? outlineService.getOutline(item.id)
        : toolService.getOutline(item.id);
    },
    saveProject: async (project) => projectService.save(project),
  }), [toolService, outlineService, toolboxService, projectService]);

  return <ConnectedFoamDesigner adapter={adapter} initialProject={savedProject} />;
}
```

The service names and record fields above are illustrative; replace them with your existing code and map the real response. Authentication, authorization, API routes, error handling at the service boundary and database persistence remain responsibilities of the host. `listOutlines`, `listToolboxes` and `saveProject` are optional; if saving is not connected the button is disabled. The adapter must have a stable identity (for example, memoize it) to avoid reloading on each render. Load a saved project before mounting and remount with a project-specific React `key` to switch projects.

The editor accepts a **single simple polygon** in physical units: `{ units: 'mm' | 'in', points: [{ x, y }, ...] }`. Point arrays without a unit are inches. It validates coordinates and nonzero area, converts millimeters to scene inches and centers the outline's bounding box before creating the foam pocket. The original outline is retained in saved project data; pocket position and rotation apply after centering. Pixel coordinates require calibration to actual millimeters in the host. The editor rejects self-intersections and contours over 2,500 points. SVG paths, curves, holes and multiple contours require conversion by the host; they are not inferred or supported by this adapter.

The save handler receives `format`, `toolId` (the original source ID), `sourceType` (`tool` or `outline`), `toolName`, the source `outline`, normalized `settings` (inches and degrees), `system`, `pocketScalePercent` and `manufacturing`. It must reject on failure. When reopening, include the matching item in `listTools` or `listOutlines`; the saved outline is a snapshot, not a live reference to the original. This is a frontend integration boundary: the actual authenticated backend is not included or connected here.

`src/App.jsx` also accepts the editor props directly for hosts that already load tools themselves. When omitted in the standalone app, `tools` and `toolboxes` use demo values; `ConnectedFoamDesigner` always supplies actual arrays, including empty arrays.

## Current limitations

- One tool/pocket per insert. Sample tools share an example outline. The platform account used for inspection had no saved items, so real backend data has not been tested.
- Pocket size is percentage scaling, not a constant physical clearance. Checks are approximate, and dimensions can be increased or positions constrained to fit the outline.
- DXF and SVG contain 2D contours in millimeters; they do not contain pocket depth or machine instructions. STL is generated from visible printable meshes in millimeters. Check exports in the target CAD/slicer and validate manufacturability before use.
- The standard foam mesh is generated as one closed solid. Gridfinity feet are exported as separate meshes touching the foam; union or repair them in your slicer if a single printable solid is required. Gridfinity tolerances need physical fit tests; compliance with a manufacturing standard is not established.
- `src/features/foam-designer` contains an older alternative editor, not the main entry point. Integrate the main `App.jsx` to retain the tool picker and export controls.
