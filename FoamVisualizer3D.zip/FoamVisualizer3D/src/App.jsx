

import { useMemo, useRef, useState } from "react";

import * as THREE from "three";

import { STLExporter } from "three/addons/exporters/STLExporter.js";

import {

  Search,

  Box,

  Wrench,

  FolderOpen,

  ArrowLeft,

  Download,

  RotateCcw,

  ZoomIn,

  ZoomOut,

  ChevronDown,

  Minus,

  Plus,

} from "lucide-react";

import { FoamScene } from "./components/FoamScene";

import {

  initialSettings,

  normalizeSettings,

  outline,

  getOutlinePoints,

  MM_PER_INCH,

} from "./lib/foam";

import {

  DEFAULT_GRIDFINITY_SETTINGS,

  getGridfinityFromSize,

} from "./lib/gridfinity";

import { prepareOutline } from "./integration/outline.js";
import "./App.css";



const DEMO_TOOLS = [

  {

    id: "demo-scissors",

    name: "Scissors",

    toolboxId: "demo-toolbox",

    outline: {

      units: "in",

      points: outline,

    },

  },

  {

    id: "demo-hammer",

    name: "Hammer",

    toolboxId: "demo-toolbox",

    outline: {

      units: "in",

      points: outline,

    },

  },

];

const DEMO_TOOLBOXES = [

  {

    id: "demo-toolbox",

    name: "My Toolbox",

  },

];

const clamp = (value, min, max) =>

  Math.max(min, Math.min(max, value));

const round = (value, digits = 4) =>

  Number(value.toFixed(digits));

function parseNumericValue(raw) {

  const text = String(raw).trim().replace(",", ".");

  if (!text || text === "-" || text === ".") {

    return null;

  }

  const value = Number(text);

  return Number.isFinite(value) ? value : null;

}



function NumberField({

  label,

  value,

  onChange,

  min = -100,

  max = 100,

  step = 0.1,

  unit = "in",

}) {

  const [draft, setDraft] = useState(null);

  const displayValue =

    draft === null ? String(value) : draft;

  function commit(raw) {

    const parsed = parseNumericValue(raw);

    if (parsed !== null) {

      onChange(clamp(parsed, min, max));

    }

    setDraft(null);

  }

  function changeByStep(direction) {

    const parsed = parseNumericValue(displayValue);

    const current =

      parsed === null ? Number(value) : parsed;

    const next = clamp(

      round(current + direction * step),

      min,

      max

    );

    onChange(next);

    setDraft(null);

  }

  return (

    <div className="tk-field">

      <label>{label}</label>

      <div className="tk-input tk-number-control">

        <button

          type="button"

          className="tk-number-step"

          aria-label={`Decrease ${label}`}

          disabled={Number(value) <= min}

          onClick={() => changeByStep(-1)}

        >

          <Minus size={12} />

        </button>

        <input

          type="text"

          inputMode="decimal"

          aria-label={label}

          value={displayValue}

          onChange={(event) => {

            const raw = event.target.value;

            setDraft(raw);

            const parsed = parseNumericValue(raw);

            if (

              parsed !== null &&

              parsed >= min &&

              parsed <= max

            ) {

              onChange(parsed);

            }

          }}

          onBlur={(event) =>

            commit(event.target.value)

          }

          onKeyDown={(event) => {

            if (event.key === "Enter") {

              event.currentTarget.blur();

            }

            if (event.key === "Escape") {

              setDraft(null);

              event.currentTarget.blur();

            }

            if (event.key === "ArrowUp") {

              event.preventDefault();

              changeByStep(1);

            }

            if (event.key === "ArrowDown") {

              event.preventDefault();

              changeByStep(-1);

            }

          }}

        />

        <span className="tk-number-unit">{unit}</span>

        <button

          type="button"

          className="tk-number-step"

          aria-label={`Increase ${label}`}

          disabled={Number(value) >= max}

          onClick={() => changeByStep(1)}

        >

          <Plus size={12} />

        </button>

      </div>

    </div>

  );

}

function Section({ number, title, children }) {

  return (

    <section className="tk-section">

      <div className="tk-section-heading">

        <span>{number}</span>

        <h3>{title}</h3>

      </div>

      {children}

    </section>

  );

}

function Toggle({ value, options, onChange }) {

  return (

    <div className="tk-toggle">

      {options.map((option) => (

        <button

          key={option.value}

          type="button"

          className={

            value === option.value ? "active" : ""

          }

          aria-pressed={value === option.value}

          onClick={() => onChange(option.value)}

        >

          {option.label}

        </button>

      ))}

    </div>

  );

}

function scaleOutline(source, percentage) {

  const points = getOutlinePoints(source);

  if (!Array.isArray(points) || points.length < 3) {

    throw new Error(

      "Outline must contain at least 3 points."

    );

  }

  const xs = points.map((point) => point.x);

  const ys = points.map((point) => point.y);

  const centerX =

    (Math.min(...xs) + Math.max(...xs)) / 2;

  const centerY =

    (Math.min(...ys) + Math.max(...ys)) / 2;

  const factor = percentage / 100;

  return {

    units: "in",

    points: points.map((point) => ({

      x: centerX + (point.x - centerX) * factor,

      y: centerY + (point.y - centerY) * factor,

    })),

  };

}

function validateOutline(source) {

  if (!source) return "The selected tool has no outline.";
  try {

    const points = getOutlinePoints(source);

    if (!Array.isArray(points) || points.length < 3) {

      return "Outline must contain at least 3 points.";

    }

    if (

      points.some(

        (point) =>

          !Number.isFinite(point.x) ||

          !Number.isFinite(point.y)

      )

    ) {

      return "Outline contains invalid coordinates.";

    }

    return null;

  } catch (error) {

    return error.message || "Invalid outline.";

  }

}

function validateManufacturing(

  settings,

  shape,

  minBottomMm,

  minEdgeMm

) {

  const warnings = [];

  const bottomMm =

    (settings.thickness - settings.depth) *

    MM_PER_INCH;

  if (bottomMm < minBottomMm) {

    warnings.push(

      "Insufficient material below the pocket."

    );

  }

  try {

    const angle =

      (settings.rotation * Math.PI) / 180;

    const cosine = Math.cos(angle);

    const sine = Math.sin(angle);

    const points = getOutlinePoints(shape).map(

      ({ x, y }) => ({

        x:

          x * cosine -

          y * sine +

          settings.x,

        y:

          x * sine +

          y * cosine +

          settings.y,

      })

    );

    const xs = points.map((point) => point.x);

    const ys = points.map((point) => point.y);

    const edgeMm =

      Math.min(

        settings.width / 2 + Math.min(...xs),

        settings.width / 2 - Math.max(...xs),

        settings.height / 2 + Math.min(...ys),

        settings.height / 2 - Math.max(...ys)

      ) * MM_PER_INCH;

    if (edgeMm < 0) {

      warnings.push(

        "Pocket extends outside the foam."

      );

    } else if (edgeMm < minEdgeMm) {

      warnings.push(

        "Pocket is too close to the foam edge."

      );

    }

  } catch {

    warnings.push(

      "Could not calculate pocket margins."

    );

  }

  return {

    bottomMm,

    warnings,

  };

}

/* TODO(INTEGRATION): Connect existing authenticated ToolKaiser data and saving. */

export default function App({

  tools = DEMO_TOOLS,

  toolboxes = DEMO_TOOLBOXES,

  outlines = [],

  onSaveProject = null,

  onLoadToolOutline = null,

  initialProject = null,

}) {

  const [settings, setSettings] = useState({

    ...initialSettings,
    ...initialProject?.settings,

  });

  const [source, setSource] = useState("tools");

  const [search, setSearch] = useState("");

  const [activeToolboxId, setActiveToolboxId] =

    useState(null);

  const [selectedToolId, setSelectedToolId] =

    useState(initialProject?.sourceType === "outline" ? `outline:${initialProject.toolId}` : initialProject?.toolId ?? null);

  const [loadedOutline, setLoadedOutline] =

    useState(initialProject?.outline ?? null);

  const [loadingTool, setLoadingTool] =

    useState(false);

  const [toolError, setToolError] = useState("");

  const [mode, setMode] = useState("perspective");

  const [system, setSystem] = useState(initialProject?.system === "gridfinity" ? "gridfinity" : "standard");

  const [zoom, setZoom] = useState(0);

  const [cameraReset, setCameraReset] = useState(0);

  const [pocketScale, setPocketScale] =

    useState(initialProject?.pocketScalePercent ?? 100);

  const [minBottomMm, setMinBottomMm] =

    useState(initialProject?.manufacturing?.minBottomMm ?? 3);

  const [minEdgeMm, setMinEdgeMm] =

    useState(initialProject?.manufacturing?.minEdgeMm ?? 5);

  const [

    manufacturingMethod,

    setManufacturingMethod,

  ] = useState(initialProject?.manufacturing?.method ?? "cnc");

  const [saving, setSaving] = useState(false);

  const [message, setMessage] = useState("");

  const requestId = useRef(0);

  const exportSceneRef = useRef(null);

  const outlineItems = useMemo(() => outlines.map(item => ({
    ...item, sourceId: item.id, sourceType: "outline", id: `outline:${item.id}`,
  })), [outlines]);

  const selectedTool = useMemo(() =>
    [...tools, ...outlineItems].find(item => item.id === selectedToolId) ?? null,
    [tools, outlineItems, selectedToolId]);

  const filteredTools = useMemo(() => {
    const query = search.toLowerCase().trim();
    const items = source === "outlines" ? outlineItems : tools;
    return items.filter(item => String(item.name).toLowerCase().includes(query) &&
      (source !== "toolboxes" || item.toolboxId === activeToolboxId));
  }, [tools, outlineItems, search, source, activeToolboxId]);

  const filteredToolboxes = useMemo(() => {

    const query = search.toLowerCase().trim();

    return toolboxes.filter((toolbox) =>

      String(toolbox.name)

        .toLowerCase()

        .includes(query)

    );

  }, [toolboxes, search]);

  const defaultOutline = useMemo(

    () => ({

      units: "in",

      points: outline,

    }),

    []

  );

  const selectedOutline =

    loadedOutline ?? selectedTool?.outline ?? null;

  const outlineError = selectedOutline

    ? validateOutline(selectedOutline)

    : null;

  const validOutline =

    Boolean(selectedOutline) && !outlineError;

  const activeOutline = useMemo(
    () => validOutline ? prepareOutline(selectedOutline) : defaultOutline,
    [validOutline, selectedOutline, defaultOutline]
  );

  const scaledOutline = useMemo(

    () => scaleOutline(activeOutline, pocketScale),

    [activeOutline, pocketScale]

  );

  const normalized = useMemo(

    () => normalizeSettings(settings, scaledOutline),

    [settings, scaledOutline]

  );

  const gridSize = useMemo(

    () =>

      getGridfinityFromSize(

        normalized.width * MM_PER_INCH,

        normalized.height * MM_PER_INCH

      ),

    [normalized.width, normalized.height]

  );

  const checks = useMemo(

    () =>

      validateManufacturing(

        normalized,

        scaledOutline,

        minBottomMm,

        minEdgeMm

      ),

    [

      normalized,

      scaledOutline,

      minBottomMm,

      minEdgeMm,

    ]

  );

  function updateSetting(key, value) {

    setSettings((previous) => {

      const next = {

        ...previous,

        [key]: value,

      };

      if (key === "thickness") {

        next.depth = Math.min(

          previous.depth,

          Math.max(0.05, value - 0.05)

        );

      }

      if (key === "depth") {

        next.depth = Math.min(

          value,

          Math.max(

            0.05,

            previous.thickness - 0.05

          )

        );

      }

      return next;

    });

    setMessage("");

  }



  async function selectTool(tool) {

    const currentRequest = ++requestId.current;

    setSelectedToolId(tool.id);

    setLoadedOutline(null);

    setToolError("");

    setMessage("");

    if (typeof onLoadToolOutline !== "function") {
      setLoadingTool(false);
      return;

    }

    setLoadingTool(true);

    try {

      const result = await onLoadToolOutline(tool.sourceType === "outline"
        ? { ...tool, id: tool.sourceId } : { ...tool, sourceType: "tool" });

      if (currentRequest !== requestId.current) {

        return;

      }

      const error = validateOutline(result);

      if (error) {

        throw new Error(error);

      }

      setLoadedOutline(result);

    } catch (error) {

      if (currentRequest === requestId.current) {

        setToolError(

          error.message ||

            "Could not load tool outline."

        );

      }

    } finally {

      if (currentRequest === requestId.current) {

        setLoadingTool(false);

      }

    }

  }

  function resetCamera() {

    setZoom(0);

    setCameraReset((value) => value + 1);

  }

  function resetSettings() {

    setSettings({ ...initialSettings });

    setPocketScale(100);

    setMinBottomMm(3);

    setMinEdgeMm(5);

    setManufacturingMethod("cnc");

    setSystem("standard");

    setMode("perspective");

    setMessage("");

    resetCamera();

  }



  // Export actual rendered meshes, not a screenshot or JSON.

  // STL coordinates are converted from scene inches to millimeters.

  function exportSTL() {
    if (loadingTool || toolError || !selectedTool || !validOutline) {
      window.alert("Wait for a valid tool outline to load.");
      return;
    }

    const scene = exportSceneRef.current;
    if (!scene) {
      const error = "3D scene is not ready. Ensure FoamScene calls onSceneReady.";
      setMessage(error);
      window.alert(error);
      return;
    }

    const printable = new THREE.Group();
    try {
      scene.updateWorldMatrix(true, true);
      let count = 0;

      scene.traverse((object) => {
        if (!object.isMesh || !object.geometry || object.userData?.excludeFromSTL) return;
        if (!object.userData?.printableSTL) return;
        // Invisible parent groups must also be excluded.
        let ancestor = object;
        while (ancestor) {
          if (!ancestor.visible) return;
          ancestor = ancestor.parent;
        }
        // The preview floor and non-solid guides are not printable.
        if (["PlaneGeometry", "CircleGeometry"].includes(object.geometry.type)) return;

        const geometry = object.geometry.clone();
        geometry.applyMatrix4(object.matrixWorld);
        // This scene models inches; STL coordinates are exported in millimeters.
        geometry.scale(MM_PER_INCH, MM_PER_INCH, MM_PER_INCH);
        printable.add(new THREE.Mesh(geometry, new THREE.MeshBasicMaterial()));
        count += 1;
      });

      if (!count) throw new Error("No printable 3D meshes were found in the scene.");
      const stl = new STLExporter().parse(printable, { binary: true });
      const blob = new Blob([stl], { type: "model/stl" });
      if (!blob.size) throw new Error("Generated STL is empty.");

      const safeName = String(selectedTool?.name || "foam")
        .toLowerCase().replace(/[^a-z0-9_-]+/g, "-");
      downloadFile(blob, `${safeName}-${system}.stl`);
      setMessage(`STL generated (${(blob.size / 1024).toFixed(1)} KB). Verify it in your slicer.`);
    } catch (error) {
      console.error("STL export error:", error);
      const reason = error instanceof Error ? error.message : String(error);
      setMessage(`STL export failed: ${reason}`);
      window.alert(`STL export failed: ${reason}`);
    } finally {
      printable.traverse((item) => {
        if (item.isMesh) {
          item.geometry.dispose();
          item.material.dispose();
        }
      });
    }
  }

  // 2D fabrication exports: outer foam boundary and transformed pocket contour.
  function export2D(format) {
    try {
      if (loadingTool || toolError || !selectedTool || !validOutline) {
        throw new Error("Wait for a valid tool outline to load.");
      }
      const inchesToMm = MM_PER_INCH;
      const width = (system === "gridfinity" ? gridSize.columns * 42 : normalized.width * inchesToMm);
      const height = (system === "gridfinity" ? gridSize.rows * 42 : normalized.height * inchesToMm);
      const angle = normalized.rotation * Math.PI / 180;
      const cosine = Math.cos(angle);
      const sine = Math.sin(angle);
      const pocket = getOutlinePoints(scaledOutline).map(({ x, y }) => ({
        x: (x * cosine - y * sine + normalized.x) * inchesToMm + width / 2,
        y: (x * sine + y * cosine + normalized.y) * inchesToMm + height / 2,
      }));
      if (pocket.length < 3) throw new Error("The pocket needs at least three points.");
      const outer = [
        { x: 0, y: 0 }, { x: width, y: 0 },
        { x: width, y: height }, { x: 0, y: height },
      ];
      const fmt = (value) => Number(value.toFixed(5)).toString();
      let contents;
      let mime;
      if (format === "svg") {
        const polygon = (points, layer) =>
          `<polygon id="${layer}" points="${points.map(p => `${fmt(p.x)},${fmt(height - p.y)}`).join(" ")}" fill="none" stroke="black" stroke-width="0.2"/>`;
        contents = `<?xml version="1.0" encoding="UTF-8"?>\n` +
          `<svg xmlns="http://www.w3.org/2000/svg" width="${fmt(width)}mm" height="${fmt(height)}mm" viewBox="0 0 ${fmt(width)} ${fmt(height)}">\n` +
          `  <g id="foam-outline">${polygon(outer, "outer-cut")}</g>\n` +
          `  <g id="tool-pocket">${polygon(pocket, "pocket-cut")}</g>\n</svg>\n`;
        mime = "image/svg+xml;charset=utf-8";
      } else if (format === "dxf") {
        // R2000-compatible lightweight polylines. $INSUNITS=4 means millimeters.
        const polyline = (points, layer) => [
          "0", "LWPOLYLINE", "8", layer, "90", String(points.length), "70", "1",
          ...points.flatMap(p => ["10", fmt(p.x), "20", fmt(p.y)]),
        ].join("\n") + "\n";
        contents = "0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1015\n9\n$INSUNITS\n70\n4\n0\nENDSEC\n" +
          "0\nSECTION\n2\nENTITIES\n" +
          polyline(outer, "FOAM_OUTER") + polyline(pocket, "TOOL_POCKET") +
          "0\nENDSEC\n0\nEOF\n";
        mime = "application/dxf";
      } else {
        throw new Error("Unsupported export format.");
      }
      const filename = String(selectedTool?.name || "foam").toLowerCase().replace(/[^a-z0-9_-]+/g, "-");
      const blob = new Blob([contents], { type: mime });
      downloadFile(blob, `${filename}-${system}.${format}`);
      setMessage(`${format.toUpperCase()} generated in millimeters (outer boundary and tool pocket).`);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      setMessage(`${format.toUpperCase()} export failed: ${reason}`);
      window.alert(`${format.toUpperCase()} export failed: ${reason}`);
    }
  }

  async function saveProject() {
    if (!selectedTool || !validOutline || loadingTool || toolError || saving) {
      setMessage("Select a tool with a valid outline before saving.");
      return;
    }
    if (typeof onSaveProject !== "function") {
      setMessage("Saving is unavailable until the platform connects its save handler.");
      return;
    }
    const project = {
      format: "toolkaiser-foam-v1",
      toolId: selectedTool.sourceId ?? selectedTool.id,
      sourceType: selectedTool.sourceType ?? "tool",
      toolName: selectedTool.name,
      outline: selectedOutline,
      settings: normalized,
      system,
      pocketScalePercent: pocketScale,
      manufacturing: { method: manufacturingMethod, minBottomMm, minEdgeMm },
    };
    setSaving(true);
    setMessage("");
    try {
      await onSaveProject(project);
      setMessage("Project saved.");
    } catch (error) {
      setMessage(`Could not save project: ${error instanceof Error ? error.message : "Please try again."}`);
    } finally {
      setSaving(false);
    }
  }

  function downloadFile(blob, filename) {
    if (!blob || blob.size === 0) throw new Error("Export generated an empty file.");
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    window.setTimeout(() => {
      link.remove();
      URL.revokeObjectURL(url);
    }, 10000);
  }


  return (

    <div className="tk-foam-editor">

      <header className="tk-foam-header">

        <div>

          <h1>Foam Designer</h1>

          <p>

            Design custom foam inserts for your tools.

          </p>

        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button type="button" className="tk-primary" onClick={saveProject} disabled={saving || !onSaveProject || !selectedTool || !validOutline || loadingTool || Boolean(toolError)} title={!onSaveProject ? "Connect the platform save handler to enable saving" : "Save project"}>
            {saving ? "Saving…" : "Save project"}
          </button>
          <button type="button" className="tk-primary" onClick={exportSTL} title="Download 3D model for slicing">
            <Download size={16} /> STL
          </button>
          <button type="button" className="tk-primary" onClick={() => export2D("dxf")} title="Download 2D contours for CAD/CNC">
            <Download size={16} /> DXF
          </button>
          <button type="button" className="tk-primary" onClick={() => export2D("svg")} title="Download 2D contours for laser/vector editing">
            <Download size={16} /> SVG
          </button>
        </div>

      </header>

      <div className="tk-foam-workspace">

        <aside className="tk-foam-sidebar">

          {/* 01 — TOOL SELECTION */}

          <Section

            number="01"

            title="Select an outline or tool"

          >

            <Toggle

              value={source}

              onChange={(value) => {

                setSource(value);

                setSearch("");

                setActiveToolboxId(null);

              }}

              options={[

                {

                  value: "tools",

                  label: "Tools",

                },

                {

                  value: "outlines",

                  label: "Outlines",

                },

                {

                  value: "toolboxes",

                  label: "Toolboxes",

                },

              ]}

            />

            {source === "toolboxes" &&

              activeToolboxId && (

                <button

                  type="button"

                  className="tk-back"

                  onClick={() => {

                    setActiveToolboxId(null);

                    setSearch("");

                  }}

                >

                  <ArrowLeft size={14} />

                  Back to toolboxes

                </button>

              )}

            <div className="tk-search">

              <Search size={16} />

              <input

                value={search}

                onChange={(event) =>

                  setSearch(event.target.value)

                }

                placeholder={

                  source === "toolboxes" &&

                  !activeToolboxId

                    ? "Search toolboxes..."

                    : source === "outlines" ? "Search outlines..." : "Search tools..."

                }

              />

            </div>

            <div className="tk-tool-list">

              {source === "toolboxes" &&

              !activeToolboxId ? (

                filteredToolboxes.length ? (

                  filteredToolboxes.map((toolbox) => (

                    <button

                      type="button"

                      key={toolbox.id}

                      className="tk-tool-item"

                      onClick={() => {

                        setActiveToolboxId(toolbox.id);

                        setSearch("");

                      }}

                    >

                      <FolderOpen size={17} />

                      <span>{toolbox.name}</span>

                      <ChevronDown size={14} />

                    </button>

                  ))

                ) : (

                  <p className="tk-empty">

                    No toolboxes found.

                  </p>

                )

              ) : filteredTools.length ? (

                filteredTools.map((tool) => (

                  <button

                    type="button"

                    key={tool.id}

                    className={`tk-tool-item ${

                      selectedToolId === tool.id

                        ? "selected"

                        : ""

                    }`}

                    onClick={() => selectTool(tool)}

                  >

                    <Wrench size={17} />

                    <span>{tool.name}</span>

                    {selectedToolId === tool.id && (

                      <span>✓</span>

                    )}

                  </button>

                ))

              ) : (

                <p className="tk-empty">

                  {source === "outlines" ? "No outlines found." : "No tools found."}

                </p>

              )}

            </div>

            {loadingTool && (

              <p className="tk-hint">

                Loading outline...

              </p>

            )}

            {toolError && (

              <p className="tk-error">

                {toolError}

              </p>

            )}

            {outlineError && selectedTool && (

              <p className="tk-error">

                {outlineError}

              </p>

            )}

          </Section>

          {/* 02 — FOAM DIMENSIONS */}

          <Section

            number="02"

            title="Foam dimensions"

          >

            <div className="tk-field-grid">

              <NumberField

                label="Width"

                value={settings.width}

                min={0.5}

                max={30}

                step={0.1}

                onChange={(value) =>

                  updateSetting("width", value)

                }

              />

              <NumberField

                label="Length"

                value={settings.height}

                min={0.5}

                max={30}

                step={0.1}

                onChange={(value) =>

                  updateSetting("height", value)

                }

              />

            </div>

            {(Math.abs(settings.width - normalized.width) > 0.0001 || Math.abs(settings.height - normalized.height) > 0.0001) && (
              <p className="tk-hint">Actual foam size adjusted to fit the outline: {normalized.width.toFixed(2)} × {normalized.height.toFixed(2)} in.</p>
            )}

            <NumberField

              label="Thickness"

              value={settings.thickness}

              min={0.1}

              max={6}

              step={0.05}

              onChange={(value) =>

                updateSetting("thickness", value)

              }

            />

            <label className="tk-color-field">

              <span>Foam color</span>

              <input

                type="color"

                value={settings.foamColor}

                onChange={(event) =>

                  updateSetting(

                    "foamColor",

                    event.target.value

                  )

                }

              />

            </label>

          </Section>

          {/* 03 — TOOL POCKET */}

          <Section

            number="03"

            title="Tool pocket"

          >

            <div className="tk-field-grid">

              <NumberField

                label="Pocket depth"

                value={settings.depth}

                min={0.05}

                max={Math.max(

                  0.05,

                  settings.thickness - 0.05

                )}

                step={0.05}

                onChange={(value) =>

                  updateSetting("depth", value)

                }

              />

              <NumberField

                label="Pocket size"

                value={pocketScale}

                min={50}

                max={150}

                step={1}

                unit="%"

                onChange={setPocketScale}

              />

            </div>

            <details className="tk-details">

              <summary>

                Position & rotation

              </summary>

              <div className="tk-details-content">

                <div className="tk-field-grid">

                  <NumberField

                    label="Horizontal"

                    value={settings.x}

                    step={0.1}

                    onChange={(value) =>

                      updateSetting("x", value)

                    }

                  />

                  <NumberField

                    label="Vertical"

                    value={settings.y}

                    step={0.1}

                    onChange={(value) =>

                      updateSetting("y", value)

                    }

                  />

                </div>

                <NumberField

                  label="Rotation"

                  value={settings.rotation}

                  min={-180}

                  max={180}

                  step={5}

                  unit="°"

                  onChange={(value) =>

                    updateSetting("rotation", value)

                  }

                />

              </div>

            </details>

          </Section>

          {/* 04 — MANUFACTURING */}

          <Section

            number="04"

            title="Manufacturing"

          >

            <label className="tk-field">

              <span>Cutting method</span>

              <select

                value={manufacturingMethod}

                onChange={(event) =>

                  setManufacturingMethod(

                    event.target.value

                  )

                }

              >

                <option value="cnc">

                  CNC routing

                </option>

                <option value="laser">

                  Laser cutting

                </option>

                <option value="manual">

                  Manual cutting

                </option>

              </select>

            </label>

            <details className="tk-details">

              <summary>

                Material margins

              </summary>

              <div className="tk-details-content">

                <div className="tk-field-grid">

                  <NumberField

                    label="Min. bottom"

                    value={minBottomMm}

                    min={0}

                    max={100}

                    step={0.5}

                    unit="mm"

                    onChange={setMinBottomMm}

                  />

                  <NumberField

                    label="Min. edge"

                    value={minEdgeMm}

                    min={0}

                    max={100}

                    step={0.5}

                    unit="mm"

                    onChange={setMinEdgeMm}

                  />

                </div>

              </div>

            </details>

            <div className="tk-result">

              <span>Bottom remaining</span>

              <strong>

                {checks.bottomMm.toFixed(1)} mm

              </strong>

            </div>

            {checks.warnings.map(

              (warning, index) => (

                <p

                  className="tk-warning"

                  key={`${warning}-${index}`}

                >

                  ⚠ {warning}

                </p>

              )

            )}

          </Section>

          {/* 05 — PREVIEW */}

          <Section

            number="05"

            title="Preview"

          >

            <p className="tk-group-label">

              CAMERA

            </p>

            <Toggle

              value={mode}

              onChange={setMode}

              options={[

                {

                  value: "perspective",

                  label: "3D View",

                },

                {

                  value: "top",

                  label: "Top View",

                },

                {

                  value: "bottom",

                  label: "Bottom View",

                },

              ]}

            />

            <p className="tk-group-label">

              BASE TYPE

            </p>

            <Toggle

              value={system}

              onChange={(value) => {

                setSystem(value);

                resetCamera();

              }}

              options={[

                {

                  value: "standard",

                  label: "Standard",

                },

                {

                  value: "gridfinity",

                  label: "Gridfinity",

                },

              ]}

            />

            {system === "gridfinity" && (

              <div className="tk-result">

                <span>Grid size</span>

                <strong>

                  {gridSize.columns} ×{" "}

                  {gridSize.rows}

                </strong>

              </div>

            )}

            {system === "gridfinity" && (

              <p className="tk-hint">

                Select Bottom View to inspect the

                Gridfinity feet underneath the foam.

              </p>

            )}

          </Section>

          <button

            type="button"

            className="tk-reset"

            onClick={resetSettings}

          >

            <RotateCcw size={15} />

            Reset settings

          </button>

          {message && (

            <p

              className="tk-message"

              role="status"

            >

              {message}

            </p>

          )}

        </aside>

        {/* 3D VIEWPORT */}

        <main className="tk-foam-preview">

          <div className="tk-preview-toolbar">

            <span>

              <Box size={15} />

              {selectedTool

                ? selectedTool.name

                : "Preview"}

            </span>

            <div>

              <button

                type="button"

                title="Zoom out"

                aria-label="Zoom out"

                onClick={() =>

                  setZoom((value) => value - 1)

                }

              >

                <ZoomOut size={16} />

              </button>

              <button

                type="button"

                title="Zoom in"

                aria-label="Zoom in"

                onClick={() =>

                  setZoom((value) => value + 1)

                }

              >

                <ZoomIn size={16} />

              </button>

              <button

                type="button"

                title="Reset camera"

                aria-label="Reset camera"

                onClick={resetCamera}

              >

                <RotateCcw size={16} />

              </button>

            </div>

          </div>

          <div className="tk-canvas" style={{ visibility: selectedTool && (loadingTool || toolError || !validOutline) ? "hidden" : "visible" }}>

            <FoamScene

              settings={normalized}

              mode={mode}

              zoom={zoom}

              reset={cameraReset}

              system={system}

              gridfinitySettings={

                DEFAULT_GRIDFINITY_SETTINGS

              }

              gridfinitySize={gridSize}

              onSceneReady={(scene) => { exportSceneRef.current = scene; }}

              outlineData={scaledOutline}

            />

          </div>

          {(!selectedTool || loadingTool || toolError || !validOutline) && (

            <div className="tk-preview-notice">

              <Search size={18} />

              <span>

                {loadingTool ? "Loading outline…" : toolError || outlineError || (selectedTool ? "This tool has no valid outline." : "Select a tool to preview its outline.")}

              </span>

            </div>

          )}

        </main>

      </div>

    </div>

  );

}
