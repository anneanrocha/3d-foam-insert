import { useMemo, useState } from "react";
import { initialSettings, normalizeSettings, outline } from "../../../lib/foam";
import { getGridfinityFromSize } from "../../../lib/gridfinity";
import { scaleOutline, checkManufacturing } from "../lib/pocket";

export function useFoamDesigner(outlineData) {
  const [settings, setSettings] = useState(() => ({ ...initialSettings }));
  const [mode, setMode] = useState("3d");
  const [system, setSystem] = useState("standard");
  const [zoom, setZoom] = useState(0);
  const [reset, setReset] = useState(0);
  const [message, setMessage] = useState("");
  const [pocketScale, setPocketScale] = useState(100);
  const [minBottomMm, setMinBottomMm] = useState(3);
  const [minEdgeMm, setMinEdgeMm] = useState(5);
  const [manufacturingMethod, setManufacturingMethod] = useState("cnc");
  const shape = useMemo(() => outlineData || { units: "in", points: outline }, [outlineData]);
  const scaledShape = useMemo(() => { try { return scaleOutline(shape, pocketScale); } catch { return shape; } }, [shape, pocketScale]);
  const normalized = useMemo(() => normalizeSettings(settings, scaledShape), [settings, scaledShape]);
  const gridSize = useMemo(() => getGridfinityFromSize(normalized.width * 25.4, normalized.height * 25.4), [normalized.width, normalized.height]);
  const { bottomMm, warnings: manufacturingWarnings } = useMemo(() => checkManufacturing(normalized, scaledShape, { minBottomMm, minEdgeMm }), [normalized, scaledShape, minBottomMm, minEdgeMm]);
  const change = (key, value) => setSettings(prev => {
    const next = { ...prev, [key]: value };
    if (key === "thickness") next.depth = Math.min(next.depth, Math.max(0.05, value - 0.05));
    if (key === "depth") next.depth = Math.min(value, Math.max(0.05, prev.thickness - 0.05));
    return next;
  });
  const resetAll = () => { setSettings({ ...initialSettings }); setSystem("standard"); setMode("3d"); setZoom(0); setReset(v => v + 1); setMessage(""); setPocketScale(100); setMinBottomMm(3); setMinEdgeMm(5); setManufacturingMethod("cnc"); };
  const resetCamera = () => { setZoom(0); setReset(v => v + 1); };
  return { settings, change, mode, setMode, system, setSystem, zoom, setZoom, reset, resetCamera, message, setMessage, pocketScale, setPocketScale, minBottomMm, setMinBottomMm, minEdgeMm, setMinEdgeMm, manufacturingMethod, setManufacturingMethod, shape, scaledShape, normalized, gridSize, bottomMm, manufacturingWarnings, resetAll };
}
