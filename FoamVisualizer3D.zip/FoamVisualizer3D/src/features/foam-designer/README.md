# Foam Designer — integration notes

## Architecture
- `FoamDesigner.jsx`: UI composition and export/save adapter.
- `components/`: single-panel settings, reusable numeric field.
- `hooks/useFoamDesigner.js`: React state, normalization and preview model.
- `lib/pocket.js`: pure geometry scaling and approximate manufacturing checks.
- `styles/foam-designer.css`: scoped editor styling.
- `src/components/FoamScene.jsx`, `GridfinityBase.jsx`, `src/lib/foam.js`, `gridfinity.js`: retained existing rendering/geometry code.

## Integrate with ToolKaiser
Import `FoamDesigner` from `features/foam-designer/FoamDesigner` and render:

```jsx
<FoamDesigner
  outlineData={selectedTool.outline}
  toolName={selectedTool.name}
  onSave={async (project) => await yourExistingSaveHandler(project)}
/>
```

`onSave` is optional: without it, the editor downloads JSON. Connect the existing website's routing, authentication, saved tool data, and persistence in the host application; no fake API calls are included.

## Limits
- One tool outline / one foam block at a time.
- Pocket size is uniform percentage scaling, **not** true cutter offset/clearance.
- Manufacturing checks are 2D approximations and not machining validation.
- Method selection is metadata only. JSON is **not** G-code or a production-ready cutting file.
- Verify actual rendering and dimensions against your real tool outlines before deployment.

## Run
Keep the project's existing `package.json` and Vite dependencies; replace its `src` with this folder, then run the project's usual dev/build commands. This archive contains `src` only.
