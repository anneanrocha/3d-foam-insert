
export default function PreviewSettings({mode, setMode, system, setSystem}) {
  return (
        <section className="foam-section">
          <div className="foam-section-heading">VIEW OPTIONS</div>
          <div className="foam-group-title">CAMERA</div>
          <div className="foam-toggle"><button className={mode === "3d" ? "selected" : ""} onClick={() => setMode("3d")}>3D view</button><button className={mode === "2d" ? "selected" : ""} onClick={() => setMode("2d")}>Top view</button></div>
          <div className="foam-group-title">BASE</div>
          <div className="foam-toggle"><button className={system === "standard" ? "selected" : ""} onClick={() => setSystem("standard")}>Standard</button><button className={system === "gridfinity" ? "selected" : ""} onClick={() => setSystem("gridfinity")}>Gridfinity</button></div>
          <p className="foam-help">Gridfinity adds a modular base beneath the foam. The preview uses the current foam footprint.</p>
        </section>
  );
}
