import NumberField from "./NumberField";

export default function FoamDimensions({settings, change}) {
  return (
        <section className="foam-section">
          <p className="foam-description">Adjust your foam and tool pocket in one place.</p>
          <div className="foam-group-title">FOAM SIZE</div>
          <NumberField label="Width" hint="Side-to-side size of the foam." value={settings.width} onChange={v => change("width", v)} min={0.5} max={30} step={0.1}/>
          <NumberField label="Length" hint="Front-to-back size of the foam." value={settings.height} onChange={v => change("height", v)} min={0.5} max={30} step={0.1}/>
          <NumberField label="Thickness" hint="Total foam thickness." value={settings.thickness} onChange={v => change("thickness", v)} min={0.1} max={6} step={0.05}/>
          <div className="foam-group-title">APPEARANCE</div>
          <label className="foam-color-row"><span>Foam color</span><input aria-label="Foam color" type="color" value={settings.foamColor} onChange={e => change("foamColor", e.target.value)}/></label>
        </section>
  );
}
