
export default function NumberField({ label, hint, value, onChange, min, max, step, unit = "in" }) {
  return <label className="foam-field"><span>{label}<span className="foam-hint" tabIndex={0} title={hint} aria-label={hint}>ⓘ</span></span><div className="foam-number"><input type="number" min={min} max={max} step={step} value={Number(Number(value).toFixed(3))} onChange={e => { const n = Number(e.target.value); if (e.target.value !== "" && Number.isFinite(n)) onChange(Math.max(min, Math.min(max, n))); }}/><span>{unit}</span></div></label>;
}
