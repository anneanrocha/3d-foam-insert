import NumberField from "./NumberField";
import { Wrench } from "lucide-react";

export default function PocketSettings({settings, change, toolName, pocketScale, setPocketScale}) {
  return (
        <section className="foam-section">
          <div className="foam-section-heading">TOOL POCKET</div>
          <div className="foam-tool-name"><Wrench size={16}/><span>{toolName}</span></div>
          <NumberField label="Pocket depth" hint="How far the tool cutout goes into the foam." value={settings.depth} onChange={v => change("depth", v)} min={0.05} max={Math.max(.05, settings.thickness - .05)} step={0.05}/>
          <div className="foam-group-title">POCKET SIZE</div>
          <NumberField label="Pocket size" hint="Scales the selected tool outline proportionally. 100% is the original saved outline; this is not an exact offset/clearance operation." value={pocketScale} onChange={setPocketScale} min={50} max={150} step={1} unit="%"/>
          <div className="foam-group-title">POSITION</div>
          <NumberField label="Horizontal" hint="Move the cutout left or right." value={settings.x} onChange={v => change("x", v)} min={-20} max={20} step={0.1}/>
          <NumberField label="Vertical" hint="Move the cutout forward or backward." value={settings.y} onChange={v => change("y", v)} min={-20} max={20} step={0.1}/>
          <NumberField label="Rotation" hint="Rotate the tool outline." value={settings.rotation} onChange={v => change("rotation", v)} min={-180} max={180} step={5} unit="°"/>
          <p className="foam-help">The tool outline comes from the website when connected. Until then, an example outline is displayed.</p>
        </section>
  );
}
