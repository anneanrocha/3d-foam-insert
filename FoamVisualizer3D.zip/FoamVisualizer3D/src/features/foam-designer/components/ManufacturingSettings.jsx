import NumberField from "./NumberField";

export default function ManufacturingSettings({manufacturingMethod, setManufacturingMethod, minBottomMm, setMinBottomMm, minEdgeMm, setMinEdgeMm, bottomMm, manufacturingWarnings}) {
  return (
        <section className="foam-section">
          <div className="foam-section-heading">MANUFACTURING</div>
          <div className="foam-group-title">MANUFACTURING METHOD</div>
          <label className="foam-select-label">Cutting process<select value={manufacturingMethod} onChange={e => setManufacturingMethod(e.target.value)}>
            <option value="cnc">CNC routing</option><option value="laser">Laser cutting</option><option value="manual">Manual cutting</option>
          </select></label>
          <div className="foam-group-title">SAFETY MARGINS</div>
          <NumberField label="Minimum bottom" hint="Desired thickness of foam left underneath the pocket." value={minBottomMm} onChange={setMinBottomMm} min={0} max={100} step={0.5} unit="mm"/>
          <NumberField label="Minimum edge" hint="Desired distance between the cutout and the foam outer edge." value={minEdgeMm} onChange={setMinEdgeMm} min={0} max={100} step={0.5} unit="mm"/>
          <div className="foam-group-title">BASIC CHECKS</div>
          <div className="foam-manufacturing-result"><strong>Bottom remaining: {bottomMm.toFixed(1)} mm</strong>
            {manufacturingWarnings.length ? manufacturingWarnings.map((warning, i) => <p key={i} className="foam-warning">⚠ {warning}</p>) : <p className="foam-good">✓ Current bottom and approximate edge margins meet your chosen minimums.</p>}
          </div>
          <p className="foam-help">These are preliminary geometry checks, not manufacturing certification. The method selection is saved as project metadata; it does not change the cut geometry or generate machine instructions.</p>
        </section>
  );
}
