import { Download, RotateCcw, ZoomIn, ZoomOut } from "lucide-react";
import { FoamScene } from "../../components/FoamScene";
import { DEFAULT_GRIDFINITY_SETTINGS } from "../../lib/gridfinity";
import { useFoamDesigner } from "./hooks/useFoamDesigner";
import FoamDimensions from "./components/FoamDimensions";
import PocketSettings from "./components/PocketSettings";
import ManufacturingSettings from "./components/ManufacturingSettings";
import PreviewSettings from "./components/PreviewSettings";
import "./styles/foam-designer.css";

/** Website integration: <FoamDesigner outlineData={tool.outline} toolName={tool.name} onSave={save} /> */
export default function FoamDesigner({ outlineData = null, toolName = "Example tool", onSave = null }) {
  const editor = useFoamDesigner(outlineData);
  const exportProject = async () => {
    const payload = { format: "toolkaiser-foam-v1", toolName, outline: editor.shape, scaledOutline: editor.scaledShape, pocketScalePercent: editor.pocketScale, settings: editor.normalized, system: editor.system, manufacturing: { method: editor.manufacturingMethod, minBottomMm: editor.minBottomMm, minEdgeMm: editor.minEdgeMm, warnings: editor.manufacturingWarnings } };
    if (typeof onSave === "function") {
      try { await onSave(payload); editor.setMessage("Project saved."); }
      catch { editor.setMessage("Save failed. Please try again."); }
      return;
    }
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "toolkaiser-foam.json"; anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    editor.setMessage("Project JSON downloaded.");
  };
  return <div className="foam-editor">
    <header className="foam-header"><div className="foam-breadcrumb"><span className="foam-symbol">K</span><span className="foam-slash">/</span><strong>Foam Designer</strong><span className="foam-slash">/</span><span>{toolName}</span></div>
      <div className="foam-header-actions"><button title="Reset camera" onClick={editor.resetCamera}><RotateCcw size={16}/></button><button title="Zoom in" onClick={() => editor.setZoom(v => v + 1)}><ZoomIn size={17}/></button><button title="Zoom out" onClick={() => editor.setZoom(v => v - 1)}><ZoomOut size={17}/></button></div>
    </header>
    <div className="foam-body"><aside className="foam-panel">
      <div className="foam-panel-intro"><h2>Foam Editor</h2><p>Adjust your insert while previewing changes.</p></div>
      <FoamDimensions settings={editor.settings} change={editor.change}/>
      <PocketSettings settings={editor.settings} change={editor.change} toolName={toolName} pocketScale={editor.pocketScale} setPocketScale={editor.setPocketScale}/>
      <ManufacturingSettings manufacturingMethod={editor.manufacturingMethod} setManufacturingMethod={editor.setManufacturingMethod} minBottomMm={editor.minBottomMm} setMinBottomMm={editor.setMinBottomMm} minEdgeMm={editor.minEdgeMm} setMinEdgeMm={editor.setMinEdgeMm} bottomMm={editor.bottomMm} manufacturingWarnings={editor.manufacturingWarnings}/>
      <PreviewSettings mode={editor.mode} setMode={editor.setMode} system={editor.system} setSystem={editor.setSystem}/>
      <div className="foam-panel-bottom"><button className="foam-primary" onClick={exportProject}><Download size={16}/>{onSave ? "Save project" : "Export project"}</button><button className="foam-reset" onClick={editor.resetAll}>Reset settings</button>{editor.message && <p className="foam-message" role="status">{editor.message}</p>}</div>
    </aside><main className="foam-viewport"><FoamScene settings={editor.normalized} mode={editor.mode} zoom={editor.zoom} reset={editor.reset} system={editor.system} gridfinitySettings={DEFAULT_GRIDFINITY_SETTINGS} gridfinitySize={editor.gridSize} outlineData={editor.scaledShape}/><div className="foam-viewport-label">{editor.mode === "3d" ? "3D preview" : "Top preview"} · {editor.system === "gridfinity" ? "Gridfinity" : "Standard foam"}</div></main></div>
  </div>;
}
