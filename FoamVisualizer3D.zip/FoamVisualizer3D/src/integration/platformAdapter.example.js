import { createFoamAdapter } from './createFoamAdapter.js';

/**
 * Integration template. Replace these four calls and map fields to your actual
 * service responses. Construct once or memoize in the host application.
 * The service must already be authenticated by the host.
 */
export function makePlatformAdapter({ toolsApi, outlinesApi, toolboxesApi, projectsApi }) {
  return createFoamAdapter({
    listTools: async () => (await toolsApi.list()).map(item => ({
      id: item.id,
      name: item.name,
      toolboxId: item.toolboxId,
    })),
    listOutlines: async () => (await outlinesApi.list()).map(item => ({ id: item.id, name: item.name })),
    listToolboxes: async () => (await toolboxesApi.list()).map(item => ({
      id: item.id,
      name: item.name,
    })),
    // Return physical coordinates: { units: 'mm' | 'in', points: [{x, y}] }.
    loadOutline: item => item.sourceType === "outline"
      ? outlinesApi.getOutline(item.id)
      : toolsApi.getOutline(item.id),
    saveProject: project => projectsApi.save(project),
  });
}
