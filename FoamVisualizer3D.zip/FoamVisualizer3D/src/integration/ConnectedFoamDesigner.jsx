import { useEffect, useState } from 'react';
import FoamDesigner from '../App.jsx';

/** Adapter identity should be stable across renders; create it outside the component or memoize it. */
export default function ConnectedFoamDesigner({ adapter, initialProject = null }) {
  const [attempt, setAttempt] = useState(0);
  const [state, setState] = useState({ status: 'loading', tools: [], outlines: [], toolboxes: [], error: '' });

  useEffect(() => {
    let active = true;
    Promise.all([adapter.listTools(), adapter.listOutlines(), adapter.listToolboxes()]).then(
      ([tools, outlines, toolboxes]) => {
        if (active) setState({ status: 'ready', tools, outlines, toolboxes, error: '' });
      },
      error => {
        if (active) setState({ status: 'error', tools: [], outlines: [], toolboxes: [], error: error?.message || 'Could not load tools.' });
      },
    );
    return () => { active = false; };
  }, [adapter, attempt]);

  if (state.status === 'loading') return <div role="status">Loading your tools…</div>;
  if (state.status === 'error') return <div role="alert"><p>{state.error}</p><button type="button" onClick={() => { setState({ status: 'loading', tools: [], outlines: [], toolboxes: [], error: '' }); setAttempt(n => n + 1); }}>Try again</button></div>;

  return <FoamDesigner tools={state.tools} outlines={state.outlines} toolboxes={state.toolboxes}
    onLoadToolOutline={adapter.loadOutline} onSaveProject={adapter.saveProject}
    initialProject={initialProject} />;
}
