import { getOutlinePoints } from '../lib/foam.js';

/** Convert a physical contour to scene inches, with its bounding box centered. */
export function prepareOutline(outline) {
  const points = getOutlinePoints(outline);
  const xs = points.map(point => point.x);
  const ys = points.map(point => point.y);
  const centerX = (Math.min(...xs) + Math.max(...xs)) / 2;
  const centerY = (Math.min(...ys) + Math.max(...ys)) / 2;
  return {
    units: 'in',
    points: points.map(({ x, y }) => ({ x: x - centerX, y: y - centerY })),
  };
}
