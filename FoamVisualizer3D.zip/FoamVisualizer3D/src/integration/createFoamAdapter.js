import { getOutlinePoints } from '../lib/foam.js';

/**
 * Bridges existing application services to the editor's data contract.
 * Map the real backend response in these functions; no URLs or auth are assumed.
 */
export function createFoamAdapter({ listTools, listOutlines, listToolboxes, loadOutline, saveProject }) {
  if (typeof listTools !== 'function' || typeof loadOutline !== 'function') {
    throw new TypeError('listTools and loadOutline are required');
  }
  return {
    async listTools() {
      const tools = await listTools();
      if (!Array.isArray(tools)) throw new Error('listTools must return an array');
      for (const tool of tools) {
        if (tool?.id == null || typeof tool.name !== 'string') {
          throw new Error('Each tool needs an id and a name');
        }
      }
      return tools;
    },
    async listOutlines() {
      if (!listOutlines) return [];
      const outlines = await listOutlines();
      if (!Array.isArray(outlines) || outlines.some(item => item?.id == null || typeof item.name !== "string")) {
        throw new Error("listOutlines must return items with an id and a name");
      }
      return outlines;
    },
    async listToolboxes() {
      if (!listToolboxes) return [];
      const toolboxes = await listToolboxes();
      if (!Array.isArray(toolboxes)) throw new Error('listToolboxes must return an array');
      return toolboxes;
    },
    async loadOutline(tool) {
      const outline = await loadOutline(tool);
      if (!outline) throw new Error("The selected tool has no outline.");
      getOutlinePoints(outline); // Reject bad data before the renderer sees it.
      return outline;
    },
    ...(saveProject ? { saveProject: project => saveProject(project) } : {}),
  };
}
