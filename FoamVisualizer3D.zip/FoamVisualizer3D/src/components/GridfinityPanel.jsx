import { Minus, Plus } from "lucide-react";
import {
  getGridfinityDimensions,
  GRIDFINITY_BASE_HEIGHT,
  GRIDFINITY_UNIT,
} from "../lib/gridfinity";

export default function GridfinityPanel({
  gridColumns,
  gridRows,
  setGridColumns,
  setGridRows,
}) {
  const dimensions = getGridfinityDimensions(
    gridColumns,
    gridRows
  );

  const changeValue = (setter, value) => {
    setter(Math.max(1, Math.min(20, value)));
  };

  return (
    <div className="gridfinity-panel">
      <div className="section-title">GRIDFINITY</div>

      <div className="gridfinity-controls">
        <div className="gridfinity-control">
          <div>
            <strong>Grid X</strong>
            <span>{gridColumns} unit{gridColumns !== 1 ? "s" : ""}</span>
          </div>

          <div className="stepper">
            <button
              type="button"
              onClick={() =>
                changeValue(
                  setGridColumns,
                  gridColumns - 1
                )
              }
              aria-label="Decrease Gridfinity X"
            >
              <Minus size={14} />
            </button>

            <b>{gridColumns}</b>

            <button
              type="button"
              onClick={() =>
                changeValue(
                  setGridColumns,
                  gridColumns + 1
                )
              }
              aria-label="Increase Gridfinity X"
            >
              <Plus size={14} />
            </button>
          </div>
        </div>

        <div className="gridfinity-control">
          <div>
            <strong>Grid Y</strong>
            <span>{gridRows} unit{gridRows !== 1 ? "s" : ""}</span>
          </div>

          <div className="stepper">
            <button
              type="button"
              onClick={() =>
                changeValue(
                  setGridRows,
                  gridRows - 1
                )
              }
              aria-label="Decrease Gridfinity Y"
            >
              <Minus size={14} />
            </button>

            <b>{gridRows}</b>

            <button
              type="button"
              onClick={() =>
                changeValue(
                  setGridRows,
                  gridRows + 1
                )
              }
              aria-label="Increase Gridfinity Y"
            >
              <Plus size={14} />
            </button>
          </div>
        </div>

        <div className="gridfinity-info">
          <span>Unit size</span>
          <strong>{GRIDFINITY_UNIT} × {GRIDFINITY_UNIT} mm</strong>
        </div>

        <div className="gridfinity-info">
          <span>Base height</span>
          <strong>{GRIDFINITY_BASE_HEIGHT} mm</strong>
        </div>

        <div className="gridfinity-info">
          <span>Total footprint</span>
          <strong>
            {dimensions.widthMm} × {dimensions.depthMm} mm
          </strong>
        </div>

        <div className="gridfinity-info">
          <span>Compatibility</span>
          <strong>Gridfinity underside</strong>
        </div>
      </div>
    </div>
  );
}
