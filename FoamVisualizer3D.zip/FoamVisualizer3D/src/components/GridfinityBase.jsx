import { useEffect, useMemo } from "react";
import * as THREE from "three";

const MM = 1 / 25.4;
const PITCH_MM = 42;
const TOP_WIDTH_MM = 41.5;
const TOP_CHAMFER_MM = 0.8;
const STRAIGHT_HEIGHT_MM = 1.8;
const LOWER_CHAMFER_MM = 2.15;
const FOOT_HEIGHT_MM = TOP_CHAMFER_MM + STRAIGHT_HEIGHT_MM + LOWER_CHAMFER_MM;
const BOTTOM_WIDTH_MM = TOP_WIDTH_MM - 2 * (TOP_CHAMFER_MM + LOWER_CHAMFER_MM);
const CORNER_RADIUS_MM = 3.75;
const MAGNET_RADIUS_MM = 3;
const MAGNET_OFFSET_MM = 10;

// Counterclockwise contour when viewed from above (+Y).
function roundedSquarePoints(widthMm, radiusMm, segments = 10) {
  const half = widthMm / 2;
  const radius = Math.min(radiusMm, half);
  const corners = [
    { x: half - radius, z: half - radius, start: 0 },
    { x: -half + radius, z: half - radius, start: 90 },
    { x: -half + radius, z: -half + radius, start: 180 },
    { x: half - radius, z: -half + radius, start: 270 },
  ];
  const points = [];
  for (const corner of corners) {
    for (let i = 0; i <= segments; i++) {
      if (i === segments && corner !== corners[corners.length - 1]) continue;
      const angle = THREE.MathUtils.degToRad(corner.start + (i * 90) / segments);
      points.push([
        (corner.x + Math.cos(angle) * radius) * MM,
        (corner.z + Math.sin(angle) * radius) * MM,
      ]);
    }
  }
  // Remove duplicated first/last point if present.
  if (points.length > 1) {
    const a = points[0];
    const b = points[points.length - 1];
    if (Math.hypot(a[0] - b[0], a[1] - b[1]) < 1e-8) points.pop();
  }
  return points;
}

function makeFootGeometry() {
  const levels = [
    { y: 0, width: TOP_WIDTH_MM },
    { y: -TOP_CHAMFER_MM, width: TOP_WIDTH_MM - 2 * TOP_CHAMFER_MM },
    { y: -(TOP_CHAMFER_MM + STRAIGHT_HEIGHT_MM), width: TOP_WIDTH_MM - 2 * TOP_CHAMFER_MM },
    { y: -FOOT_HEIGHT_MM, width: BOTTOM_WIDTH_MM },
  ];

  // Build a separate quad for each side segment to keep the chamfers crisp.
  const positions = [];
  const normals = [];
  const indices = [];

  function addTriangle(a, b, c) {
    const ab = new THREE.Vector3().subVectors(b, a);
    const ac = new THREE.Vector3().subVectors(c, a);
    const normal = new THREE.Vector3().crossVectors(ab, ac).normalize();
    const offset = positions.length / 3;
    for (const point of [a, b, c]) {
      positions.push(point.x, point.y, point.z);
      normals.push(normal.x, normal.y, normal.z);
    }
    indices.push(offset, offset + 1, offset + 2);
  }

  const rings = levels.map(({ y, width }) =>
    roundedSquarePoints(width, Math.min(CORNER_RADIUS_MM, width * 0.22)).map(
      ([x, z]) => new THREE.Vector3(x, y * MM, z)
    )
  );

  const count = rings[0].length;
  for (let level = 0; level < rings.length - 1; level++) {
    for (let i = 0; i < count; i++) {
      const j = (i + 1) % count;
      const a = rings[level][i];
      const b = rings[level][j];
      const c = rings[level + 1][j];
      const d = rings[level + 1][i];
      // CCW contour in XZ has outward-facing winding as below.
      addTriangle(a, b, c);
      addTriangle(a, c, d);
    }
  }

  const cap2d = rings[0].map((p) => new THREE.Vector2(p.x, p.z));
  const capTriangles = THREE.ShapeUtils.triangulateShape(cap2d, []);
  const last = rings[rings.length - 1];
  for (const [a, b, c] of capTriangles) {
    addTriangle(rings[0][a], rings[0][c], rings[0][b]);
    addTriangle(last[a], last[b], last[c]);
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
  geometry.setIndex(indices);
  geometry.computeBoundingSphere();
  return geometry;
}

// Visual markers only; they do not cut printable magnet holes.
function MagnetPocketMarker({ x, z }) {
  return (
    <mesh position={[x, -FOOT_HEIGHT_MM * MM - 0.015 * MM, z]} rotation={[Math.PI / 2, 0, 0]}>
      <circleGeometry args={[MAGNET_RADIUS_MM * MM, 32]} />
      <meshBasicMaterial color="#34414b" side={THREE.DoubleSide} depthWrite={false} />
    </mesh>
  );
}

export default function GridfinityBase({ columns = 2, rows = 2, baseMagnets = "none" }) {
  const safeColumns = Math.max(1, Math.floor(Number(columns) || 1));
  const safeRows = Math.max(1, Math.floor(Number(rows) || 1));
  const geometry = useMemo(() => makeFootGeometry(), []);

  useEffect(() => () => geometry.dispose(), [geometry]);

  const cells = useMemo(() => {
    const result = [];
    for (let row = 0; row < safeRows; row++) {
      for (let col = 0; col < safeColumns; col++) {
        result.push({
          key: `${col}-${row}`,
          x: ((col + 0.5) * PITCH_MM - (safeColumns * PITCH_MM) / 2) * MM,
          z: ((row + 0.5) * PITCH_MM - (safeRows * PITCH_MM) / 2) * MM,
        });
      }
    }
    return result;
  }, [safeColumns, safeRows]);

  const magnetPositions = useMemo(() => {
    if (baseMagnets === "none") return [];
    // Both settings currently display markers only. Physical cavity geometry is a future step.
    const offset = MAGNET_OFFSET_MM * MM;
    return [
      [-offset, -offset],
      [offset, -offset],
      [-offset, offset],
      [offset, offset],
    ];
  }, [baseMagnets]);

  return (
    <group>
      {cells.map((cell) => (
        <group key={cell.key} position={[cell.x, 0, cell.z]}>
          <mesh geometry={geometry} userData={{ printableSTL: true }} castShadow receiveShadow>
            <meshStandardMaterial color="#8b949d" roughness={0.78} metalness={0} flatShading />
          </mesh>
          {magnetPositions.map(([x, z], index) => (
            <MagnetPocketMarker key={index} x={x} z={z} />
          ))}
        </group>
      ))}
    </group>
  );
}
