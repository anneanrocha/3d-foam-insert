import { Canvas, useThree } from "@react-three/fiber";
import GridfinityBase from "./GridfinityBase";

import {
  Environment,
  Lightformer,
  Line,
  OrbitControls,
} from "@react-three/drei";

import {
  Suspense,
  useEffect,
  useMemo,
  useRef,
} from "react";

import * as THREE from "three";

import { rotatedOutline, getOutlinePoints } from "../lib/foam";
import { createFoamGeometry } from "../lib/foamGeometry.js";

const GRIDFINITY_UNIT_MM = 42;

function shadeColor(hex, amount) {
  const color = new THREE.Color(hex);

  color.multiplyScalar(amount);

  return `#${color.getHexString()}`;
}

/*
 * Gridfinity uses 42 mm per unit.
 *
 * The existing Three.js scene uses inches as
 * its working unit, so we convert mm -> inches.
 */
function gridfinityToInches(columns, rows) {
  return {
    width: (columns * GRIDFINITY_UNIT_MM) / 25.4,
    height: (rows * GRIDFINITY_UNIT_MM) / 25.4,
  };
}

function FoamModel({
  settings,
  system,
  gridColumns,
  gridRows,
  outlineData,
}) {
  /*
   * Foam dimensions
   *
   * Standard:
   * uses the normal foam width/height.
   *
   * Gridfinity:
   * foam footprint follows the Gridfinity
   * unit dimensions.
   */
  const foamDimensions = useMemo(() => {
    if (system === "gridfinity") {
      return gridfinityToInches(
        gridColumns,
        gridRows
      );
    }

    return {
      width: settings.width,
      height: settings.height,
    };
  }, [
    system,
    gridColumns,
    gridRows,
    settings.width,
    settings.height,
  ]);

  /*
   * Tool pocket outline.
   *
   * IMPORTANT:
   * The pocket still exists in Gridfinity mode.
   * Gridfinity is underneath the foam, not the pocket.
   */
  const points = useMemo(() => {
    const basePoints = outlineData ? getOutlinePoints(outlineData) : rotatedOutline(0);
    const angle = settings.rotation * Math.PI / 180;
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    return basePoints.map((point) => ({
      x: point.x * cos - point.y * sin + settings.x,
      y: point.x * sin + point.y * cos + settings.y,
    }));
  }, [
    settings.rotation,
    settings.x,
    settings.y,
    outlineData,
  ]);

  const geometry = useMemo(() => createFoamGeometry({
    width: foamDimensions.width,
    height: foamDimensions.height,
    thickness: settings.thickness,
    depth: settings.depth,
  }, points), [foamDimensions.width, foamDimensions.height, settings.thickness, settings.depth, points]);

  useEffect(() => () => geometry.dispose(), [geometry]);

  /*
   * Foam texture.
   */
  const texture = useMemo(() => {
    const size = 128;

    const data = new Uint8Array(
      size * size * 4
    );

    let seed = 731;

    for (
      let index = 0;
      index < size * size;
      index++
    ) {
      seed =
        (Math.imul(
          seed,
          1664525
        ) +
          1013904223) >>>
        0;

      const value =
        195 + (seed % 50);

      data.set(
        [
          value,
          value,
          value,
          255,
        ],
        index * 4
      );
    }

    const texture =
      new THREE.DataTexture(
        data,
        size,
        size
      );

    texture.wrapS =
      THREE.RepeatWrapping;

    texture.wrapT =
      THREE.RepeatWrapping;

    texture.repeat.set(3, 3);

    texture.needsUpdate = true;

    return texture;
  }, []);

  useEffect(() => {
    return () => {
      texture.dispose();
    };
  }, [texture]);

  const topColor =
    settings.foamColor ||
    "#86898d";

  const edgeColor =
    shadeColor(
      topColor,
      1.35
    );

  /*
   * Outer foam edge.
   */
  const edge = points.map(
    (point) => [
      point.x,
      settings.thickness + 0.008,
      -point.y,
    ]
  );

  if (edge.length) {
    edge.push(edge[0]);
  }

  /*
   * Foam itself.
   */
  return (
    <group>

      <mesh geometry={geometry} userData={{ printableSTL: true }} castShadow receiveShadow>
        <meshStandardMaterial color={topColor} roughness={0.95} map={texture} />
      </mesh>

      {/* Foam outline */}

      <Line
        points={edge}
        color={edgeColor}
        lineWidth={1.4}
      />

    </group>
  );
}

function CameraRig({
  mode,
  zoom,
  reset,
  settings,
  system,
  gridColumns,
  gridRows,
}) {
  const {
    camera,
    invalidate,
    size,
  } = useThree();

  const controls =
    useRef(null);

  const dimensions =
    useMemo(() => {
      if (
        system ===
        "gridfinity"
      ) {
        return gridfinityToInches(
          gridColumns,
          gridRows
        );
      }

      return {
        width:
          settings.width,
        height:
          settings.height,
      };
    }, [
      system,
      gridColumns,
      gridRows,
      settings.width,
      settings.height,
    ]);

  useEffect(() => {
    const aspect =
      size.width /
      Math.max(
        size.height,
        1
      );

    const angle =
      Math.atan(
        Math.tan(
          (21 * Math.PI) /
            180
        ) *
          Math.min(
            aspect,
            1
          )
      );

    const distance =
      Math.max(
        11,
        (Math.hypot(
          dimensions.width,
          dimensions.height
        ) /
          2 /
          Math.sin(
            angle
          )) *
          1.12
      );

    const direction =
      new THREE.Vector3(
        ...(mode === "top"
          ? [0, 1, 0.0001]
          : mode === "bottom"
          ? [0, -1, 0.0001]
          : mode === "front"
          ? [0, 0.15, 1]
          : [8, 8, 9])
      ).normalize();

    camera.position.copy(
      direction.multiplyScalar(
        distance
      )
    );

    camera.lookAt(
      0,
      0,
      0
    );

    controls.current?.target.set(
      0,
      0,
      0
    );

    controls.current?.update();

    invalidate();
  }, [
    mode,
    reset,
    camera,
    invalidate,
    size.width,
    size.height,
    dimensions.width,
    dimensions.height,
  ]);

  const previousZoom =
    useRef(zoom);

  useEffect(() => {
    camera.position.multiplyScalar(
      Math.pow(
        0.85,
        zoom -
          previousZoom.current
      )
    );

    previousZoom.current =
      zoom;

    controls.current?.update();

    invalidate();
  }, [
    zoom,
    camera,
    invalidate,
  ]);

  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enableDamping
      enableRotate={mode !== "top" && mode !== "bottom"}
      enablePan
      enableZoom
      minPolarAngle={0.01}
      minDistance={3}
      maxDistance={45}

      /*
       * IMPORTANT:
       * Allow the user to rotate underneath
       * the foam and see the Gridfinity structure.
       */
      maxPolarAngle={
        Math.PI - 0.01
      }
    />
  );
}

export function FoamScene({
  settings,
  mode,
  zoom,
  reset,
  system = "standard",
  gridColumns = 2,
  gridRows = 2,
  gridfinitySettings = {},
  gridfinitySize,
  onSceneReady,
  outlineData,
}) {
  const actualGridColumns = gridfinitySize?.columns ?? gridColumns;
  const actualGridRows = gridfinitySize?.rows ?? gridRows;

  return (
    <Canvas
      onCreated={({ scene }) => onSceneReady?.(scene)}
      shadows
      dpr={[1, 1.5]}
      camera={{
        position: [8, 8, 9],
        fov: 42,
        near: 0.01,
        far: 100,
      }}
      gl={{
        antialias: true,
      }}
    >

      <color
        attach="background"
        args={["#17191c"]}
      />

      <ambientLight
        intensity={0.8}
      />

      <directionalLight
        position={[3, 8, 5]}
        intensity={2.3}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-camera-left={-7}
        shadow-camera-right={7}
        shadow-camera-top={7}
        shadow-camera-bottom={-7}
      />

      <Suspense
        fallback={null}
      >

        <Environment
          resolution={64}
        >

          <Lightformer
            intensity={1.5}
            position={[0, 6, 0]}
            rotation-x={
              -Math.PI / 2
            }
            scale={[10, 10, 1]}
            color="#ffffff"
          />

          <Lightformer
            intensity={0.7}
            position={[-6, 2, 0]}
            rotation-y={
              Math.PI / 2
            }
            scale={[5, 5, 1]}
            color="#ffffff"
          />

        </Environment>

        {/* FOAM */}

        <FoamModel
          settings={settings}
          system={system}
          gridColumns={actualGridColumns}
          gridRows={actualGridRows}
          outlineData={outlineData}
        />

        {/* GRIDFINITY UNDER THE FOAM */}

        {system ===
          "gridfinity" && (
          <GridfinityBase
            columns={actualGridColumns}
            rows={actualGridRows}
            baseMagnets={gridfinitySettings?.baseMagnets ?? "none"}
          />
        )}

      </Suspense>

      {/* 
       * Standard gets the normal workspace grid.
       * Gridfinity does NOT.
       */}

      {system !==
        "gridfinity" && (
        <gridHelper
          args={[
            30,
            60,
            "#3c4148",
            "#2a2d31",
          ]}
          position-y={-0.02}
        />
      )}

      <CameraRig
        mode={mode}
        zoom={zoom}
        reset={reset}
        settings={settings}
        system={system}
        gridColumns={actualGridColumns}
        gridRows={actualGridRows}
      />

    </Canvas>
  );
}